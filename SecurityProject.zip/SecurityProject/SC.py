import base64
import socket
import queue
import struct
import threading
from cryptography.fernet import Fernet




def receive_messages(sock, message_queue):
      while True:
        data = sock.recv(1024)
        if not data:
            break

        message_queue.put(data)


HOST = "127.0.0.1"  
PORT = 65432  
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    s.sendall(b"Hello, world")
    queue = queue.Queue()
    receive_thread = threading.Thread(target=receive_messages, args=(s, queue))
    receive_thread.start()
    receive_thread.join()
   
    keypack = queue.queue[1]
   
    x = struct.unpack('17s 2i 64s i',keypack)
   
    Key = x[3]
    key_bytes = base64.urlsafe_b64decode(Key)
    print('Unpacked Key:', key_bytes)
    
    cipher_suite = Fernet(key_bytes)
    encryptedmessage = queue.queue[3]
    print("the encryptedmessage is :", encryptedmessage)
    decrypted_message = cipher_suite.decrypt(encryptedmessage).decode()
    print("Decrypted message:", decrypted_message)
    #condition_message = "Condition met!"
    #s.sendall(condition_message.encode())
    



   
    

       
          
    
    
    
    


   # while(queue.empty()!=True):
    #     print(queue.get_nowait())   
   # queue.put_nowait(data)
   