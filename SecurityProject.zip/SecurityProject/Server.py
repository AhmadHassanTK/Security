import base64
from cryptography.fernet import Fernet

import struct
import socket
import time

def generate_key():
    key = Fernet.generate_key()
    return key[:16]

privacyflag_1 = b"Server"
privacyflag_2 = 5
privacyNetworkOperationMode = b"Star Mode"
privacySecurityLevelDecisionMode = b"Battery Level"
privacySecurityLevel = 2
privacyTTL = 30
privacyExpectedPackets = 10

PrivacyPolicyPacket = struct.pack('17s i 8s 17s i i i',privacyflag_1,privacyflag_2,privacyNetworkOperationMode,privacySecurityLevelDecisionMode,privacySecurityLevel,privacyTTL,privacyExpectedPackets)


Keyflag_1 = b"Server"
Keyflag_2 = 5
KeyLenth = 20
#key128 = generate_key()[:16]
#Key192 = Fernet.generate_key()[:24]
Key256 = Fernet.generate_key()
KeyTime = 5
key_base64 = base64.urlsafe_b64encode(Key256)

KeyPacket = struct.pack('17s 2i 64s i',Keyflag_1,Keyflag_2,KeyLenth,key_base64,KeyTime)


Eventflag_1 = b"Server"
Eventflag_2 = 5
Event = b"Power Failure"
ProposedAction = b"Shutdown"

EventPacket = struct.pack('17s i 16s 20s',Eventflag_1,Eventflag_2,Event,ProposedAction)



HOST = "127.0.0.1" 
PORT = 65432  

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    s.listen()
    conn, addr = s.accept()
    print('Server is listening for incoming connections...')
    Key = base64.urlsafe_b64decode(key_base64)
    message2 = "helloahmad".encode()
    print("message:", message2)
    print("The Key:", Key)
    cipher_suite = Fernet(Key)
    encryptedmessage = cipher_suite.encrypt(message2)
    print("Encrypted message:", encryptedmessage)
    notifiedmessage = conn.recv(1024)
    print(notifiedmessage.decode())
    X = [PrivacyPolicyPacket,KeyPacket,EventPacket,encryptedmessage]
    for message in X:
         conn.send(message)
         time.sleep(1)

    #notifiedmessage2 = conn.recv(1024)

        
   # print(notifiedmessage2.decode())      
  
        
     
    
   # conn.close()
   # s.close()




       
        